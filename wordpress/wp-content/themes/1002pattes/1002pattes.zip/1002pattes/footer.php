        <footer class="blocfooter">
            <div itemscope itemtype="http://schema.org/Organization" class="blocfooter__content">
                <p class="blocfooter__text" itemprop="legalName">La maison du 1002 pattes</p>
            </div>
            <img src="./assets/images/logo-2.jpg" alt="logo 1002 pattes" width="105" height="128" class="blocfooter__img">
            <div class="blocfooter__flex" itemscope itemtype="http://schema.org/Organization">
                <div itemprop="address">
                    <p class="blocfooter__flex--adresse fitem">Route de Neufchâteau 73 Bastogne</p>
                    <meta itemprop="name" content="La maison du 1002 pattes">
                </div>
                <p class="blocfooter__flex--tel fitem" itemprop="telephone">+32 (0)61/46.60.08</p>
                <p class="blocfooter__flex--compte fitem">N° de compte : BE16 0016 9474 2974</p>
            </div>
        </footer>
    <script src="./assets/js/bundle.js"></script>
    <!--<script type="text/javascript">var link = document.querySelector('.indexpage');link.setAttribute("href", "./pages/aide.html");</script>-->
    </body>
</html>